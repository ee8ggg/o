<?php
date_default_timezone_set("Asia/Baghdad");
error_reporting(0);
if (!file_exists("ID")) {
$g = readline("id >>>: ");
file_put_contents("ID", $g);
}
if (!file_exists("token")) {
$g = readline("Token >>>: ");
file_put_contents("token", $g);
}
file_put_contents("type", "a");
file_put_contents("type2", "a");
file_put_contents("type3", "a");
file_put_contents("type4", "a");
file_put_contents("type5", "a");
file_put_contents("type6", "a");
file_put_contents("type7", "a");
file_put_contents("type8", "a");
file_put_contents("step", "");
file_put_contents("step2", "");
file_put_contents("step3", "");
file_put_contents("step4", "");
file_put_contents("step5", "");
file_put_contents("step6", "");
file_put_contents("step7", "");
file_put_contents("step8", "");
if (!file_exists("phone1")) {
file_put_contents("phone1", "-No number");
}
if (!file_exists("phone2")) {
file_put_contents("phone2", "-No number");
}
if (!file_exists("phone3")) {
file_put_contents("phone3", "-No number");
}
if (!file_exists("phone4")) {
file_put_contents("phone4", "-No number");
}
if (!file_exists("phone5")) {
file_put_contents("phone5", "-No number");
}
if (!file_exists("phone6")) {
file_put_contents("phone6", "-No number");
}
if (!file_exists("phone7")) {
file_put_contents("phone7", "-No number");
}
if (!file_exists("phone8")) {
file_put_contents("phone8", "-No number");
}
if (!file_exists("info.json")) {
file_put_contents("info.json", "");
}
$info = json_decode(file_get_contents('info.json'),true);
$info["number1"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number2"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number3"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number4"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number5"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number6"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number7"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info["number8"] = "-No number";
file_put_contents('info.json', json_encode($info));
$info = json_decode(file_get_contents('info.json'),true);
$info["num1"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num2"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num3"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num4"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num5"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num6"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num7"] = "off";
file_put_contents('info.json', json_encode($info));
$info["num8"] = "off";
file_put_contents('info.json', json_encode($info));
echo "RUNNING.... 🕤\n";
shell_exec("screen -dmS bot php7.4 bott.php");
shell_exec("pm2 start 1a.php");
shell_exec("pm2 start 1c.php");
shell_exec("pm2 start 2a.php");
shell_exec("pm2 start 2c.php");
shell_exec("pm2 start 3a.php");
shell_exec("pm2 start 3c.php");
shell_exec("pm2 start 4a.php");
shell_exec("pm2 start 4c.php");
shell_exec("pm2 start 5a.php");
shell_exec("pm2 start 5c.php");
shell_exec("pm2 start 6a.php");
shell_exec("pm2 start 6c.php");
shell_exec("pm2 start 7a.php");
shell_exec("pm2 start 7c.php");
shell_exec("pm2 start 8a.php");
shell_exec("pm2 start 8c.php");

shell_exec("pm2 stop 1a.php");
shell_exec("pm2 stop 1c.php");
shell_exec("pm2 stop 2a.php");
shell_exec("pm2 stop 2c.php");
shell_exec("pm2 stop 3a.php");
shell_exec("pm2 stop 3c.php");
shell_exec("pm2 stop 4a.php");
shell_exec("pm2 stop 4c.php");
shell_exec("pm2 stop 5a.php");
shell_exec("pm2 stop 5c.php");
shell_exec("pm2 stop 6a.php");
shell_exec("pm2 stop 6c.php");
shell_exec("pm2 stop 7a.php");
shell_exec("pm2 stop 7c.php");
shell_exec("pm2 stop 8a.php");
shell_exec("pm2 stop 8c.php");
echo "ONE MINUTES..\n";
echo "Done ✅\n\n\n\n";